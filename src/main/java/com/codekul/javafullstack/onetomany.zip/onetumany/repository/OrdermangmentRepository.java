package com.codekul.javafullstack.onetumany.repository;

import com.codekul.javafullstack.onetumany.domain.Ordermangment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrdermangmentRepository extends JpaRepository<Ordermangment,Long> {



}

