package com.codekul.javafullstack.onetumany.service;

import com.codekul.javafullstack.onetumany.domain.Ordermangment;

public interface OrdermangmentService {

    String saveOrdermangment(Ordermangment ordermangment);

}
