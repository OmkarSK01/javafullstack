package com.codekul.javafullstack.onetumany.service;

import com.codekul.javafullstack.onetumany.domain.Ordermangment;
import com.codekul.javafullstack.onetumany.repository.OrdermangmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrdermangmentImpl implements OrdermangmentService{

    @Autowired
    private OrdermangmentRepository ordermangmentRepository;

    @Override
    public String saveOrdermangment(Ordermangment ordermangment) {
//        if(ordermangment.getName().equals("omkar")){
//            return "omkar ordermangment not allowed";
//        }
        ordermangmentRepository.save(ordermangment);
        return "order is successful..";
    }
}

