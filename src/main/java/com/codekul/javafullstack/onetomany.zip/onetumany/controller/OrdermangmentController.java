package com.codekul.javafullstack.onetumany.controller;

import com.codekul.javafullstack.onetumany.domain.Ordermangment;
import com.codekul.javafullstack.onetumany.service.OrdermangmentService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class OrdermangmentController {
    @Autowired
    private OrdermangmentService ordermangmentService;

    @PostMapping("saveOrdermangment")
    public String saveOrdermangment(@RequestBody Ordermangment ordermangment){

        return ordermangmentService.saveOrdermangment(ordermangment);
    }


}





//postman obj
/*{
        "name": "yash",
        "address": "mumbai",
        "contact": "9168845682",
        "email": "omkarkharate1@gmail.com",
        "password": "omkae123",
        "orders": [
        {
        "name": "paneertikka",
        "number": 90978
        },
        {
        "name": "pavbhaji",
        "number": 9666
        }
        ]
        } */
